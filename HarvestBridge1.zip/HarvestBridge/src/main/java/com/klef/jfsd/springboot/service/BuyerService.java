package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Buyer;

public interface BuyerService {
	
	public String buyerRegistration(Buyer buyer);
	
	public Buyer checkBuyerLogin(String email,String password);

}
