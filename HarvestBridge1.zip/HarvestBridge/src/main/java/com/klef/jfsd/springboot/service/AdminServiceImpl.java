package com.klef.jfsd.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Buyer;
import com.klef.jfsd.springboot.model.Former;
import com.klef.jfsd.springboot.repository.AdminRepository;
import com.klef.jfsd.springboot.repository.BuyerRepository;
import com.klef.jfsd.springboot.repository.FormerRepository;
@Service
public class AdminServiceImpl implements AdminService{
private FormerRepository formerRepository;
private BuyerRepository buyerRepository;

@Autowired
private AdminRepository adminRepository;

	
	@Override
	public List<Former> viewAllFormers() {
		return formerRepository.findAll();
	}

	@Override
	public List<Buyer> viewAllBuyers() {
		return buyerRepository.findAll();
	}

	@Override
	public Admin checkAdminLogin(String uname, String pwd) {
		return adminRepository.checkAdminLogin(uname, pwd);
	}

}
