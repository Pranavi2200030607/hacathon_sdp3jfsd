package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Former;

public interface FormerService {
	public String formerRegistration(Former former);
	
	public Former checkFormerLogin(String email,String password);
	

}
