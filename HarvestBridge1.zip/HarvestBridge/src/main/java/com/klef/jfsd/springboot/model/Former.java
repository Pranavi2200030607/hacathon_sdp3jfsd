package com.klef.jfsd.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

@Entity
@Table(name="Former_table")
public class Former {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="former_id",nullable = false,length = 100)
	private int id;
	@Column(name="former_name",nullable = false,length = 10)
	private String name;
	@Column(name="former_gender",nullable = false,length = 20)
	private String gender;
	@Column(name="former_dateofbirth",nullable = false,length = 100)
	private String dateofbirth;
	@Column(name="former_email",nullable = false,unique = true,length = 100)
	private String email;
	@Column(name="former_password",nullable = false,length = 100)
	private String password;
	@Column(name="former_location",nullable = false,length = 100)
	private String location;
	@Column(name="former_contact",nullable = false,unique = true,length =20 )
	private String contact;

}
