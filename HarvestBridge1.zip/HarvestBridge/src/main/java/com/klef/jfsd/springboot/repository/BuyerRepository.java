package com.klef.jfsd.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.model.Buyer;

@Repository
public interface BuyerRepository extends JpaRepository<Buyer, Integer>{
	
	@Query("SELECT c FROM Buyer c WHERE c.email = ?1 AND c.password = ?2")
	Buyer checkCustomerLogin(String email, String password);

}
