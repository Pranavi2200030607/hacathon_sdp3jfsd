package com.klef.jfsd.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FormerController {
	@GetMapping("former_reg")
	public ModelAndView former_reg() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("former_reg");
		return mv;
	}
	
	@GetMapping("former_login")
	public ModelAndView former_login() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("former_login");
		return mv;
	}
	
	

}
