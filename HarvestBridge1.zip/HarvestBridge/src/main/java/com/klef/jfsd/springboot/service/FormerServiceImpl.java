package com.klef.jfsd.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Former;
import com.klef.jfsd.springboot.repository.FormerRepository;
@Service
public class FormerServiceImpl implements FormerService{

	@Autowired
	private FormerRepository formerRepository;
	@Override
	public String formerRegistration(Former former) {
		formerRepository.save(former);
		return "Customer Registered Sucessfully";
	}

	@Override
	public Former checkFormerLogin(String email, String password) {
		return formerRepository.checkCustomerLogin(email, password);
	}

}
