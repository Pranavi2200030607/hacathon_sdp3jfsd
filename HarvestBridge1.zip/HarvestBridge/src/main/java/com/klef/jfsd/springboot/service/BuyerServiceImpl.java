package com.klef.jfsd.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Buyer;
import com.klef.jfsd.springboot.repository.BuyerRepository;

@Service
public class BuyerServiceImpl implements BuyerService{
	@Autowired
	private BuyerRepository buyerRepository;
	
	

	@Override
	public String buyerRegistration(Buyer buyer) {
		buyerRepository.save(buyer);
		return "Buyer Registered Sucessfully";
	}

	@Override
	public Buyer checkBuyerLogin(String email, String password) {
		return buyerRepository.checkCustomerLogin(email, password);
	}
	

}
