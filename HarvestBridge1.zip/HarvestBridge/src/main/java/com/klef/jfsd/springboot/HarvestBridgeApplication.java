package com.klef.jfsd.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarvestBridgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarvestBridgeApplication.class, args);
		System.out.println("Lets connect to formers through HarvestBridge Where Farmers Meet Global Demand");
	}

}
