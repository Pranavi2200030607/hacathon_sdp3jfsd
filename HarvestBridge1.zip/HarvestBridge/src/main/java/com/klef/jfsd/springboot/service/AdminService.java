package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Buyer;
import com.klef.jfsd.springboot.model.Former;

public interface AdminService {
	public List<Former>viewAllFormers();
	public List <Buyer>viewAllBuyers();
	
	public Admin checkAdminLogin(String uname,String pwd);

}
